package org.iitwf.selenium.mmpequinox.driver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverScript {
	
	public static WebDriver driver;
	static Properties prop;
	
	/*
	 * this Constructor loads and reads environment.properties file.
	 */
	
	public DriverScript()
	{
		try
		{
			
				loadPropertiesFile("./src/test/resources/config/environment.properties");
				String environment = prop.getProperty("env.name");
				System.out.println("Environment Name :" + environment);
				if(environment.equals("qa"))
				{
					loadPropertiesFile("./src/test/resources/config/qa_config.properties");
				}
				else
				{
					loadPropertiesFile("./src/test/resources/config/dev_config.properties");
				}
				

		}
		catch(Exception e)
		{
			System.out.println("Unable to load environment.properties file");
			e.getMessage();
			e.printStackTrace();
		}
	}
	
	/*
	 * this method is used to load environment properties file.
	 */
	
	public void loadPropertiesFile(String filepath) throws IOException
	{
		File file = new File(filepath);
		FileInputStream fis = new FileInputStream(file);
		prop = new Properties();
		prop.load(fis);
	}
	
	
	/*
	 * this method is used to invoke browser based on properties file.
	 */
	
	public void initApplication()
	{
		String browser = prop.getProperty("browser.type");
		
		if(browser.trim().equalsIgnoreCase("chrome"))
		{
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-save-address-bubble");
			options.addArguments("--disable-save-password-bubble");
			driver = new ChromeDriver(options);
		}
		else if(browser.trim().equalsIgnoreCase("firefox")) 
		{
			driver = new FirefoxDriver();
		}
		else if(browser.trim().equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
		}
		else
		{
			System.out.println("Unsupported Browser.Please check the config file.");
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// Calling App url Method. 
		getAppurl();
		
	}
	
	/*
	 * this method is used to get app url from environment.properties file.
	 */
	
	public static void getAppurl()
	{
		String URL = prop.getProperty("app.url");
		
		driver.get(URL);
	}
	
	/*
	 * this method is used to quit the driver.
	 */
	
	public static void quitDriver()
	{
		driver.quit();
	}
	

}
