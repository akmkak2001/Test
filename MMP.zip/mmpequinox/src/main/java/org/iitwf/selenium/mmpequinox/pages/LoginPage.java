package org.iitwf.selenium.mmpequinox.pages;

import org.iitwf.selenium.mmpequinox.driver.DriverScript;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends DriverScript{
	
		//**************************** Page Elements/Locators ******************
	
		@FindBy(id = "username") WebElement username;
		@FindBy(id = "password") WebElement password;
		@FindBy(name = "submit") WebElement signin;
		@FindBy(xpath = "//a[text()='forgot Username / Password']") WebElement forgotUsernamePasswordlink;
		
		//**************************** Page Initialization *********************
		
		public LoginPage()
		{
			PageFactory.initElements(driver, this);
		}
		
		
		//**************************** Page Actions/Methods ********************
		
		public String loginPageTitle()
		{
			return driver.getTitle();
		}
		
		public boolean isForgotusernamePasswordLinkDisplayed()
		{
			return forgotUsernamePasswordlink.isDisplayed();
		}
		
		public void enterUsername(String uname)
		{
			username.sendKeys(uname);
		}
		
		public void enterPassword(String pwd)
		{
			password.sendKeys(pwd);
		}
		
		public void clickSubmitButton()
		{
			signin.click();
		}

		
}
