package org.iitwf.selenium.mmpequinox.pages;

import org.iitwf.selenium.mmpequinox.driver.DriverScript;
import org.iitwf.selenium.mmpequinox.utils.RandomTextAndNumbergeneration;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPage extends DriverScript{
	
		//**************************** Page Elements/Locators ******************
	
	
		@FindBy(xpath = "//input[@value='Register']") WebElement register;
		@FindBy(name = "fname") WebElement patientFirstName;
		@FindBy(name = "LastName") WebElement patientLastName;
		@FindBy(name = "dob") WebElement patientDob;
		@FindBy(name = "license") WebElement patientLic;
		@FindBy(name = "ssn") WebElement patientSsn;
		@FindBy(name = "state") WebElement patientState;
		@FindBy(name = "city") WebElement patientCity;
		@FindBy(name = "address") WebElement patientAddress;
		@FindBy(name = "zipcode") WebElement patientZipcode;
		@FindBy(name = "age") WebElement patientAge;
		@FindBy(name = "height") WebElement patientHeight;
		@FindBy(name = "weight") WebElement patientWeight;
		@FindBy(name = "pharmacy") WebElement patientPharmacy;
		@FindBy(name = "pharma_adress") WebElement patientPharmaAdress;
		@FindBy(name = "email") WebElement patientEmail;
		@FindBy(name = "username") WebElement patientUsername;
		@FindBy(name = "pwd1") WebElement pwd;
		@FindBy(name = "pwd2") WebElement confirmPwd;
		@FindBy(name = "question") WebElement patientSecurityQ;
		@FindBy(name = "answer") WebElement patientSecurityAnswer;
		@FindBy(name = "register") WebElement save;
		
		
		//**************************** Page Initialization *********************
		
		public RegistrationPage()
		{
			PageFactory.initElements(driver, this);
		}
		
				
		//**************************** Page Actions/Methods ********************
		
		public String regPageTitle()
		{
			return driver.getTitle();
		}
		
		public void clickRegisterButton()
		{
			register.click();
		}
		
		
		public void registerPatient()
		{
			patientFirstName.sendKeys(RandomTextAndNumbergeneration.getRandomFirstName());
			patientLastName.sendKeys(RandomTextAndNumbergeneration.getRandomLastName());
			patientDob.sendKeys(RandomTextAndNumbergeneration.getRandomDate());
			//patientLic.sendKeys(String.valueOf(RandomTextAndNumbergeneration.getRandomNumber()));
			//patientLic.sendKeys(RandomTextAndNumbergeneration.getLicNumber());
			patientLic.sendKeys("11111111");
			patientSsn.sendKeys(RandomTextAndNumbergeneration.getSSNNumber());
			patientState.sendKeys(RandomTextAndNumbergeneration.getRandomState());
			patientCity.sendKeys(RandomTextAndNumbergeneration.getRandomCity());
			patientAddress.sendKeys(RandomTextAndNumbergeneration.getRandomAddress());
			patientZipcode.sendKeys(RandomTextAndNumbergeneration.getRandomZipCode());
			patientAge.sendKeys("45");
			patientHeight.sendKeys("175");
			patientWeight.sendKeys("55");
			patientPharmacy.sendKeys("CVS");
			patientPharmaAdress.sendKeys(RandomTextAndNumbergeneration.getRandomAddress());
			patientEmail.sendKeys(RandomTextAndNumbergeneration.getRandomEmail());
			String userName = RandomTextAndNumbergeneration.getRandomUsername();
			patientUsername.sendKeys(userName);
			String password = RandomTextAndNumbergeneration.getRandomPassword(15);
			pwd.sendKeys(password);
			confirmPwd.sendKeys(password);
			RandomTextAndNumbergeneration.selectAndFilterOption1(patientSecurityQ, "Select Security Question");
			patientSecurityAnswer.sendKeys("Testing");
			//Thread.sleep(2000);
			save.click();
			driver.switchTo().alert().accept();
			
		}

}
