package org.iitwf.selenium.mmpequinox.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class Helper {
	
	public static String capturescreenshot(WebDriver driver)
	{
		String timeStamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String repname="Screen"+timeStamp+".png";
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); //typecasting
		//String screenpath = "/Users/dad/eclipse-workspace/com.webshop.automation/reports/screenshots/"+repname;
		//String screenpath = "/Users/dad/eclipse-workspace/com.webshop.automation/reports/screenshots/screen.png";
		String screenpath = System.getProperty("user.dir")+"/reports/screenshots"+" "+repname;
		try {
			FileHandler.copy(src, new File(screenpath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return screenpath;
		
	}
	
	public static void sleep()
	{
		try 
		{
			Thread.sleep(3000);
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

}
