package org.iitwf.selenium.mmpequinox.tests;

import java.util.Arrays;
import java.util.Collections;

public class ArraySort {

	public static void main(String[] args) {
		
		        Integer[] array = {3, 5, 1, 4, 2};

		        // Sort array in ascending order
		        Arrays.sort(array);
		        System.out.println("Sorted array: " + Arrays.toString(array));

		        // Reverse the sorted array
		        Collections.reverse(Arrays.asList(array));
		        System.out.println("Reversed array: " + Arrays.toString(array));
		    }

}

