package org.iitwf.selenium.mmpequinox.tests;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.iitwf.selenium.mmpequinox.driver.DriverScript;
import org.iitwf.selenium.mmpequinox.pages.LoginPage;
import org.iitwf.selenium.mmpequinox.pages.RegistrationPage;
import org.iitwf.selenium.mmpequinox.utils.ExcelUtil;
import org.iitwf.selenium.mmpequinox.utils.Helper;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


public class BaseTest extends DriverScript{
	
	protected static ExtentHtmlReporter extent;
	protected static ExtentReports report;
	protected static ExtentTest logger;
	
	LoginPage lp;
	RegistrationPage rp;
	
	@BeforeSuite
	public void setupReports()
	{
		String timeStamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String repname="TestReport"+" - "+timeStamp+".html";
		extent = new ExtentHtmlReporter(System.getProperty("user.dir")+"/reports/"+repname);
		//extent = new ExtentHtmlReporter("./reports/index.html");
		report = new ExtentReports();
		report.attachReporter(extent);
		
	}
	
	@BeforeMethod
	public void setup()
	{
		initApplication();
		lp = new LoginPage();
		rp = new RegistrationPage();
		
	}
	
	@AfterMethod
	public void tearDown(ITestResult result)
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			try
			{
				logger.fail("Test Failed",MediaEntityBuilder.createScreenCaptureFromPath(Helper.capturescreenshot(driver)).build());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		//Helper.sleep();
		report.flush();
		quitDriver();
	}
	
	@DataProvider(name="wsdata")
	public Object[][] testdata() throws IOException
	{
		String filepath = "./src/test/resources/testdata/wsdata.xlsx";
		int rcount = ExcelUtil.getRowCount(filepath,"sheet0");
		System.out.println("row count :"+rcount);
		
		Object[][] data = new Object[rcount][2];
		
		for(int i=0;i<rcount;i++)
		{
			data[i][0] = ExcelUtil.getCellData(filepath, "sheet0", i, 0);
			data[i][1] = ExcelUtil.getCellData(filepath, "sheet0", i, 1);
			//data[i][1] = ExcelUtil.getCellData(filepath, "sheet0", i, 1);
		}
		
		return data;
	}

}
