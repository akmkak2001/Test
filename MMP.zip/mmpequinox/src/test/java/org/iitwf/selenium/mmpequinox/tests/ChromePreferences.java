package org.iitwf.selenium.mmpequinox.tests;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromePreferences {
	
    public static void main(String[] args) {
        
    	//System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
    	
    	 ChromeOptions options = getChromeOptions();
    	 WebDriver driver = new ChromeDriver(options);
    	 driver.get("http://85.209.95.122/MMP-Release2-Integrated-Build.6.8.000/portal/login.php");

    	 // Your test code here

    	 driver.quit();
    }
    	public static ChromeOptions getChromeOptions()
    	{
	        Map<String, Object> prefs = new HashMap<>();
	        prefs.put("credentials_enable_service", false);
	        prefs.put("profile.password_manager_enabled", false);
	        prefs.put("profile.default_content_setting_values.notifications", 2);
	        prefs.put("profile.default_content_settings.cookies", 1);
	        prefs.put("profile.managed_default_content_settings.images", 2);
	        prefs.put("profile.default_content_settings.javascript", 1);
	        prefs.put("profile.autofill_address_enabled", false);
	        prefs.put("profile.autofill_profile_enabled", false);
	        //prefs.put("profile.default_content_settings.popups", 1);
	        //prefs.put("profile.default_content_settings.geolocation", 2);
	        //prefs.put("download.default_directory", "/your/download/directory/path");
	        prefs.put("safebrowsing.enabled", true);
	
	        ChromeOptions options = new ChromeOptions();
	        options.setExperimentalOption("prefs", prefs);
	        options.addArguments("--start-maximized");
	        options.addArguments("--disable-web-security");
	        options.addArguments("--no-proxy-server");
	
	        return options;
        
    	};

       
    }

