package org.iitwf.selenium.mmpequinox.tests;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FutureDate {

	public static void main(String[] args) {
		
		Calendar cal = Calendar.getInstance();
		//cal.add(Calendar.DAY_OF_MONTH, 30);
		System.err.println(cal.getTime());
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM/dd/YYYY");
		String date = sdf.format(cal.getTime());
		System.err.println("Formatted Date :" + date);

	}

}
