package org.iitwf.selenium.mmpequinox.tests;

import org.testng.Assert;
import org.testng.annotations.Test;


public class LoginPageTest extends BaseTest{
	
	@Test(priority = 1)
	public void login() 
	{
		logger = report.createTest("Validate Login Page Title");
		String LoginPageTitle = lp.loginPageTitle();
		System.out.println("Login Page Title :" + LoginPageTitle);
		logger.pass("Getting Login page Title"+" - "+LoginPageTitle);
		Assert.assertTrue(LoginPageTitle.contains("Login"));;
		lp.enterUsername("ria1");;
		logger.pass("Entered Username");
		lp.enterPassword("Ria12345");
		logger.pass("Entered Password");
		lp.clickSubmitButton();
		logger.pass("Clicked Signin Button");
	}
	
	/*@Test(enabled = true, dataProvider = "wsdata")
	public void multipleloginpwd(String username, String password) 
	{
		logger = report.createTest("Multiple Username and Password login test");
		hp.clickloginlink();
		logger.pass("Clicked on login link");
		lp.enterEmailId(username);
		logger.pass("Entered Username");
		lp.enterPassword(password);
		logger.pass("Entered Password");
		lp.clickloginbutton();
		logger.pass("Clicked on login button");
		Helper.sleep();
		
	}*/
	
}
