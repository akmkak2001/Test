package org.iitwf.selenium.mmpequinox.tests;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

import org.iitwf.selenium.mmpequinox.driver.DriverScript;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginTest extends DriverScript{
	
	//static WebDriver driver = new ChromeDriver();

	public static void main(String[] args) throws InterruptedException 
	{
		login("ria1","Ria12345");
		actualTextHashMap();
		
		ArrayList<String> expectedMenuArrayList = readMenuTitles();
		ArrayList<String> actualMenuArrayList = fetchMenuTitlesFromUI();
		
		System.out.println("Expected Array List" + expectedMenuArrayList);
		System.out.println("Actual Array List" + actualMenuArrayList);
		
		System.out.println(actualMenuArrayList.equals(expectedMenuArrayList));
		
		HashMap<String,String> expectedTextHashMap = expectedTextHashMap();
		HashMap<String,String> actualTextHashMap = actualTextHashMap();
		
		System.out.println("Expected HashMap" + expectedTextHashMap);
		System.out.println("Actual HashMap" + actualTextHashMap);
		
		System.out.println(expectedTextHashMap.equals(actualTextHashMap));
		
		if(actualMenuArrayList.equals(expectedMenuArrayList) && expectedTextHashMap.equals(actualTextHashMap))
		{
			System.out.println("Following are the modules deployed successfully "+ actualMenuArrayList + " and Sanity Tests are passed!!!!!.");
		}
		
		driver.quit();
	
	}
	
	public static ArrayList<String> fetchMenuTitlesFromUI()
	{
		List<WebElement> actualList = driver.findElements(By.xpath("//div[@class='sidebar-holder']/ul/li/a/span"));
		ArrayList<String> actualMenuArrayList = new ArrayList<String>();
		for(int i = 0;i<actualList.size();i++)
		{
		 	actualMenuArrayList.add(actualList.get(i).getText().trim());
		}
		
		Arrays.sort(actualMenuArrayList.toArray());  
		return actualMenuArrayList;
	}
 	public static ArrayList<String> readMenuTitles()
	{

		ArrayList<String> expectedMenuArrayList= new ArrayList<String>();
		expectedMenuArrayList.add("HOME");
		expectedMenuArrayList.add("Profile");
		expectedMenuArrayList.add("Schedule Appointment");
		expectedMenuArrayList.add("Information");
		expectedMenuArrayList.add("Fees");
		expectedMenuArrayList.add("Search Symptoms");
		expectedMenuArrayList.add("Messages");
		expectedMenuArrayList.add("Logout");
		
		Arrays.sort(expectedMenuArrayList.toArray());
		return expectedMenuArrayList;
	}	
 	
 	public static HashMap<String,String> expectedTextHashMap()
 	{
 		HashMap<String,String> expectedTextHashMap = new HashMap<String,String>();
 		expectedTextHashMap.put("HOME", "Patient Portal");
 		expectedTextHashMap.put("Profile", "Personal Details");
 		expectedTextHashMap.put("Schedule Appointment", "Current Appointments");
 		expectedTextHashMap.put("Information", "Information");
 		expectedTextHashMap.put("Fees", "Fees");
 		expectedTextHashMap.put("Search Symptoms", "Search Symptoms");
 		expectedTextHashMap.put("Messages", "Messages");
 		
 		return expectedTextHashMap;
 	}
 	
 	public static HashMap<String, String> actualTextHashMap() 
 	{
 	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
 	    List<WebElement> list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='sidebar-holder']/ul/li/a/span")));
 	    HashMap<String, String> actualTextHashMap = new HashMap<>();

 	    JavascriptExecutor js = (JavascriptExecutor) driver;
 	    int retryLimit = 3;  // Set a retry limit

 	    // Print the size of the list to see if elements are being found
 	    System.out.println("List size: " + list.size());

 	    for (int i = 0; i < list.size()-1; i++) 
 	    {
 	        for (int retryCount = 0; retryCount < retryLimit; retryCount++) 
 	        {
 	            try {
 	                
 	            	// Re-locate the elements in each iteration to avoid stale element reference
 	                list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='sidebar-holder']/ul/li/a/span")));
 	                WebElement ls = list.get(i);

 	                // Print the text of each element before any action
 	                String elementText = ls.getText().trim();
 	                System.out.println("Element text before click: " + elementText);
 	            
 	                // Scroll into view before clicking
 	                //js.executeScript("arguments[0].scrollIntoView(true);", ls);
 	                wait.until(ExpectedConditions.elementToBeClickable(ls));
 	                System.out.println(elementText + " - Element Clicked ");
 	                //ls.click(); //org.openqa.selenium.ElementClickInterceptedException
 	                js.executeScript("arguments[0].click();", ls); 
 	                

 	                WebElement textElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='panel-heading']/h3[@class='panel-title']")));
 	                String retrievedText = textElement.getText().trim();
 	                System.out.println("Retrieved text: " + retrievedText);

 	                // Debug statement to check the values being added
 	                if (!elementText.isEmpty() && !retrievedText.isEmpty()) 
 	                {
 	                    System.out.println("Adding to HashMap: Key = " + elementText + ", Value = " + retrievedText);
 	                    actualTextHashMap.put(elementText, retrievedText);
 	                    
 	                } else 
 	                {
 	                    System.out.println("Skipped adding empty or null values to HashMap");
 	                }
 	                
 	                break;  // Break out of the retry loop on success
 	            } 
 	            catch (StaleElementReferenceException e) 
 	            {
 	                // Handle stale element reference exception
 	                System.out.println("Encountered a stale element, retrying...");
 	                continue;  // Continue to retry the current element
 	            } 
 	            catch (NoSuchElementException e) 
 	            {
 	                // Handle no such element exception
 	                System.out.println("Element not found: " + e.getMessage());
 	                break;
 	            }
 	        }
 	    }

 	    return actualTextHashMap;
 	}
 	
	public static void login(String usr, String pwd)
	{
		
		String expectedText = "Patient Portal";
		
		
		/*driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		
		driver.get("http://85.209.95.122/MMP-Release2-Integrated-Build.6.8.000/portal/login.php");*/
		
		WebElement username = driver.findElement(By.id("username"));
		WebElement password = driver.findElement(By.id("password"));
		
		username.sendKeys(usr);
		password.sendKeys(pwd);
		
		//username.sendKeys("ria1");
		//password.sendKeys("Ria12345");
		
		WebElement signIn = driver.findElement(By.name("submit"));
		
		signIn.click();
		
		WebElement text = driver.findElement(By.xpath("//h3[normalize-space()='Patient Portal']"));
		
		if(expectedText.equals(text.getText()))
		{
			System.out.println("Login Successful");
			
		}
		else
		{
			System.out.println("Login Unsuccessful");
		}
		
	}
	
	public static void logout()
	{
		// Logout
 		WebElement logout = driver.findElement(By.xpath("//span[normalize-space()='Logout']"));
	 	logout.click();
	 	System.out.println("Logout Successful");
	 	driver.quit();
}
		
}

