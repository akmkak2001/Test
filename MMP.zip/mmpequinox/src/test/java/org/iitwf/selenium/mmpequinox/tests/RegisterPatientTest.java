package org.iitwf.selenium.mmpequinox.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterPatientTest extends BaseTest{

	
	@Test(priority = 1)
	public void registerPatient()
	{
		logger = report.createTest("Patient Registration");
		logger.pass("Clicking Register Button");
		rp.clickRegisterButton();
		String regPageTitle = rp.regPageTitle();
		Assert.assertTrue(regPageTitle.contains("Registration"));
		logger.pass("Registering Patient");
		rp.registerPatient();
		
	}
}
