package org.iitwf.selenium.mmpequinox.tests;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SanityTest {

	public static void main(String[] args) {
		
		String expectedText = "Patient Portal";
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	
		driver.get("http://85.209.95.122/MMP-Release2-Integrated-Build.6.8.000/portal/login.php");
		
		WebElement username = driver.findElement(By.id("username"));
		WebElement password = driver.findElement(By.id("password"));
		
		username.sendKeys("ria1");
		password.sendKeys("Ria12345");
		
		WebElement signIn = driver.findElement(By.name("submit"));
		
		signIn.click();
		
		WebElement text = driver.findElement(By.xpath("//h3[normalize-space()='Patient Portal']"));
		
		if(expectedText.equals(text.getText()))
		{
			System.out.println("Login Successful");
			
		}
		else
		{
			System.out.println("Login Unsuccessful");
		}
		
		String[] expectedtext = {"Patient Portal","Personal Details","Current Appointments","Information","Fees","Search Symptoms","Messages","logout"};

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		List<WebElement> list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='sidebar-holder']/ul/li/a/span")));
		//List<WebElement> list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//ul[contains(@class,'nav-list')]//li//span[@class='hidden-minibar']")));
		boolean textFound = true;

		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < list.size()-1; i++) 
		{
		    try {
		        // Re-locate the elements in each iteration to avoid stale element reference
		        list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='sidebar-holder']/ul/li/a/span")));
		        //list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//ul[contains(@class,'nav-list')]//li//span[@class='hidden-minibar']")));
		        WebElement ls = list.get(i);

		        // Scroll into view before clicking
		        js.executeScript("arguments[0].scrollIntoView(true);", ls);
		        wait.until(ExpectedConditions.elementToBeClickable(ls));
		        System.out.println(ls.getText() + " - Tile Clicked ");
		        js.executeScript("arguments[0].click();", ls);
		        WebElement textElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h3[normalize-space()='"+expectedtext[i]+"']")));
	            String retrievedtext = textElement.getText();
	            
	            if(retrievedtext.equals(expectedtext[i]))
	            {
	            	System.out.println("Text found: " + retrievedtext);
	            }
	            else
	            {
	            	System.out.println("Text not found. Retrieved: " + retrievedtext);
	            	textFound = false;
	            }
		        
		    } catch (StaleElementReferenceException e) {
		        // Handle stale element reference exception
		        System.out.println("Encountered a stale element, retrying...");
		        i--;  // Decrement the index to retry the same element
		    }
		}
		
		// Check the final status of the flag
		if (textFound) {
		    System.out.println("All expected texts were found successfully.");
		    System.out.println("Sanity test ran successfully.");
		} else {
		    System.out.println("One or more expected texts were not found.");
		    System.out.println("Sanity test failed.");
		}
		
		// Logout
		WebElement logout = driver.findElement(By.xpath("//span[normalize-space()='Logout']"));
		logout.click();
		driver.quit();

	}
	
}

