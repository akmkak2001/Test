package org.iitwf.selenium.mmpequinox.tests;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ScheduleAppointment extends LoginTest{
	
	

	public static void main(String[] args) {
		
		/*
		 * 
		 * Monday,Tuesday,Thursday - 9 pm 
		 * 
		 * 
		Formatted Date:::February/20/2025
		Same Year 
		Same Month -> Click on the date - 2
		----------------------------------------
		Formatted Date:::April/20/2025 - split("/") - [0] - April,[1]- 20,[2]-2025
		Same Year 
		Different Month - Expected Year - April -> Click on next button
		Different Month - Expected Year - December -> till i see the month as December 
		---------------------------------------------------------------------------------
		Formatted Date: April/20/2026
		Different Year - Click on next button till 2026 is displayed 
		Different Month - Click on next button till April is displayed 
		click on 20th as date 
		---------------------------------------------------------------------
		*/
		
		LoginTest.login("ria1","Ria12345");
		scheduleApp(5,"MM/dd/yyyy","Dr.Annabeth","Primary Care","Test symptoms"); //Same Month , Same Year , Same Day
		//scheduleApp(40,"MM/dd/yyyy","Dr.Sophia Rich","Cardiologist","High Fever"); // Next Month , Same Year 
		//scheduleApp(365,"MM/dd/yyyy","Dr.Alexander","Dermitologost","Cold and Fever"); // Next Year 
		LoginTest.logout();
		
		
	}
	
	public static String DateFormatter (String date)
	{
		SimpleDateFormat inputFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat outputFormat = new SimpleDateFormat("MMMM/dd/yyyy");
		Date parsedDate;
		
		try 
		{
			parsedDate = inputFormat.parse(date);
		} 
		catch (ParseException e) 
		{
			e.printStackTrace();
			return null;
		}
		
		return outputFormat.format(parsedDate);
	}
	
	public static String generateFutureDate(int n, String format)
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, n);
		//System.out.println(cal.getTime());
		
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String date = sdf.format(cal.getTime());
		//System.out.println("Formatted Date :" + date);
		
		return date;

	}
	
	public static String[] dateSplit(String formattedDate)
	{
        
        return formattedDate.split("/");
	}
	
	public static HashMap<String, String> expectedAppHashMap(String date, String appTime, String symptoms, String doctor)
	{
		HashMap<String, String> appInfo = new HashMap<String, String>();
		String appDetails = "Date :" + date + " Time :" + appTime + " Symptoms :" + symptoms;
		
		appInfo.put(doctor, appDetails);
		
		return appInfo;
		
	}
	
	public static void scheduleApp(int n, String format, String doctorName, String description, String symptoms) 
	{
		
		String newDate = generateFutureDate(n, format);
		System.out.println("Requested Date: " + newDate);
		String formattedDate = DateFormatter(newDate);
		System.out.println("Formatted Date: " + formattedDate);
		String[] dateParts = dateSplit(formattedDate);
		String month = dateParts[0];
        String day = dateParts[1];
        int dy = Integer.parseInt(day);
        String year = dateParts[2];
        //int yr = Integer.parseInt(year);
		System.out.print("Month: " + month+" ");
        System.out.print("Day: " + day+" ");
        System.out.print("Year: " + year+" ");
		
		WebElement scheduleApp = driver.findElement(By.xpath("//span[contains(text(),'Schedule Appointment')]"));
		scheduleApp.click();
		
		WebElement newApp = driver.findElement(By.xpath("//input[@value='Create new appointment']"));
		newApp.click();
		
		description = "Description:" + description;
		
		WebElement doctor = driver.findElement(By.xpath("//ul[li/h4[text()='"+ doctorName +"']//following-sibling::div/p[text()='"+ description +"']]/following-sibling::button[1]"));
		
		doctor.click();
		
		WebElement frame = driver.findElement(By.xpath("//iframe[@id='myframe']"));
		
		// Switch to the frame
        driver.switchTo().frame(frame);
        
		WebElement datePicker = driver.findElement(By.xpath("//input[@id='datepicker']"));
		datePicker.click();
		
		while(true)
		{
			WebElement m = driver.findElement(By.xpath("//div/span[@class='ui-datepicker-month']"));
			WebElement y = driver.findElement(By.xpath("//div/span[@class='ui-datepicker-year']"));
			
			if(month.equals(m.getText()) && year.equals(y.getText()))
			{
				WebElement d = driver.findElement(By.xpath("//a[normalize-space()='"+ dy +"']"));
				d.click();
				System.out.println();
				System.out.println("Reached the given month and year : " + month +"/" + year);
				break;
			}
			
			WebElement nextBtn = driver.findElement(By.xpath("//span[text()='Next']"));
			nextBtn.click();
		}
		
		
		Select time = new Select(driver.findElement(By.xpath("//select[@id='time']")));
		time.selectByVisibleText("11Am");
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='OK']")));
		
		WebElement continuebutton = driver.findElement(By.xpath("//button[@id='ChangeHeatName']"));
		continuebutton.click();
		
		driver.switchTo().defaultContent();
		
		WebElement textarea = driver.findElement(By.id("sym"));
		//String symptoms = "Test for symptoms - Fever and Cold";
		textarea.sendKeys(symptoms);
		
		WebElement submit = driver.findElement(By.xpath("//input[@value='Submit']"));
		submit.click();
		
		WebElement row = driver.findElement(By.xpath("//table/tbody/tr[1]"));
		
		List<WebElement> cells = row.findElements(By.tagName("td"));
		
		/*int i=0;
		
		while(i < cells.size())
		{
			String cellText = cells.get(i).getText();

            // Print the value of the cell
            System.out.println("Cell " + (i + 1) + ": " + cellText);

            // Increment the index
            i++;
		}*/
		
		String date = cells.get(0).getText();
		String apptime = cells.get(1).getText();
		String sym = cells.get(2).getText();
		String doc = "Dr."+cells.get(3).getText();

        // Print the value of the cell
        System.out.println("Date :"+ date);
        System.out.println("Time :"+ apptime);
        System.out.println("Symptoms :"+ sym);
        System.out.println("Doctor :"+ doc);
        
        if(newDate.equals(date) && symptoms.equals(sym) && doctorName.equals(doc))
        {
        	System.out.println("Appointment has been scheduled successfully with " + doctorName + " At :" + apptime);
        	System.out.println("Validation without HashMap");
        }
        
        HashMap<String, String> actualAppHashMap = new HashMap<String, String>();
		String appDetails = "Date :" + date + " Time :" + apptime + " Symptoms :" + sym;
		
		actualAppHashMap.put(doc, appDetails);
		
		HashMap<String, String> expectedAppHashMap = expectedAppHashMap(newDate, "11Am", symptoms, doctorName);
		
		if(actualAppHashMap.equals(expectedAppHashMap))
		{
			System.out.println("Appointment has been scheduled successfully with " + doctorName + " At :" + apptime);
			System.out.println("ExpectedAppHashMap and ActualAppHashMap are equal.");
		}
		
		for (HashMap.Entry<String, String> entry : actualAppHashMap.entrySet()) {
            System.out.println("ActualHashMap :" + "Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
		
		for (HashMap.Entry<String, String> entry : expectedAppHashMap.entrySet()) {
            System.out.println("ExpectedHashMap :" + "Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        
        
}

}
