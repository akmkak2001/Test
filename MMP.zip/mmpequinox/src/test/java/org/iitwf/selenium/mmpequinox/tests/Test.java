package org.iitwf.selenium.mmpequinox.tests;

import org.iitwf.selenium.mmpequinox.driver.DriverScript;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Test extends DriverScript{

	public static void main(String[] args) {
		
		
		DriverScript script = new DriverScript();
		script.initApplication();
		login("ria1","Ria12345");
		quitDriver();
		
	}
	
	public static void login(String usr, String pwd)
	{
		
		String expectedText = "Patient Portal";
		
		WebElement username = driver.findElement(By.id("username"));
		WebElement password = driver.findElement(By.id("password"));
		
		username.sendKeys(usr);
		password.sendKeys(pwd);
		
		WebElement signIn = driver.findElement(By.name("submit"));
		
		signIn.click();
		
		WebElement text = driver.findElement(By.xpath("//h3[normalize-space()='Patient Portal']"));
		
		if(expectedText.equals(text.getText()))
		{
			System.out.println("Login Successful");
			
		}
		else
		{
			System.out.println("Login Unsuccessful");
		}
		
	}

}
