package org.iitwf.selenium.mmpequinox.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

public class UpdateProfile extends LoginTest{

	public static void main(String[] args) {
		
		
		LoginTest.login("ria1","Ria12345");
		updateProfileValues();
		LoginTest.logout();

	}
	
	
	public static void updateProfileValues()
	{
		driver.findElement(By.xpath("//span[text()=' Profile ']")).click();
		driver.findElement(By.xpath("//input[@value='Edit']")).click();
		WebElement pTitle = driver.findElement(By.xpath("//h3[normalize-space()='Personal Details']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", pTitle);
		
		WebElement fname = driver.findElement(By.xpath("//input[@id='fname']"));
		String rFirstName = RandomTextAndNumbergeneration.getRandomFirstName();
		fname.clear();
		fname.sendKeys(rFirstName);
		WebElement lname = driver.findElement(By.xpath("//input[@id='lname']"));
		String rLastName = RandomTextAndNumbergeneration.getRandomLastName();
		lname.clear();
		lname.sendKeys(rLastName);
		WebElement License = driver.findElement(By.xpath("//input[@id='licn']"));
		String rLicense = String.valueOf(RandomTextAndNumbergeneration.getLicNumber());
		License.clear();
		License.sendKeys(rLicense);
		WebElement ssn = driver.findElement(By.xpath("//input[@id='ssn']"));
		String rssn = String.valueOf(RandomTextAndNumbergeneration.getSSNNumber());
		ssn.clear();
		ssn.sendKeys(rssn);
		WebElement address = driver.findElement(By.xpath("//input[@id='addr']"));
		String stNumber = String.valueOf(RandomTextAndNumbergeneration.getRandomStreetNumber());
		String stName = String.valueOf(RandomTextAndNumbergeneration.getRandomStreetName());
		address.clear();
		address.sendKeys(stNumber + " " +stName);
		driver.findElement(By.xpath("//input[@id='Sbtn']")).click();
		
		driver.switchTo().alert().accept();
		WebElement pTitle1 = driver.findElement(By.xpath("//h3[normalize-space()='Personal Details']"));
		js.executeScript("arguments[0].scrollIntoView(true);", pTitle1);
		
		String displayedFname = driver.findElement(By.xpath("//input[@id='fname']")).getDomAttribute("value");
		String displayedLname = driver.findElement(By.xpath("//input[@id='lname']")).getDomAttribute("value");
		String displayedLic = driver.findElement(By.xpath("//input[@id='licn']")).getDomAttribute("value");
		String displayedSSN = driver.findElement(By.xpath("//input[@id='ssn']")).getDomAttribute("value");
		String displayedAdd = driver.findElement(By.xpath("//input[@id='addr']")).getDomAttribute("value");
		
		if(displayedFname.equals(rFirstName) && displayedLname.equals(rLastName) && displayedLic.equals(rLicense) && displayedSSN.equals(rssn) && displayedAdd.equals(stNumber + " " +stName))
		{
			System.out.println("Updated Values match Entered Values.Testcase passed.");
		}
		
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(displayedFname, rFirstName);
		softAssert.assertEquals(displayedLname, rLastName);
		softAssert.assertEquals(displayedLic, rLicense);
		softAssert.assertEquals(displayedSSN, rssn);
		softAssert.assertEquals(displayedAdd, stNumber + " " +stName);
		
		softAssert.assertAll();
		
		// Define Fluent Wait
        /*FluentWait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofSeconds(5))
                .ignoring(NoSuchElementException.class);

        // Wait for "Submit" button to be present
        WebElement submitButton = wait.until(driver -> driver.findElement(By.id("submit-button")));

        // Perform actions on the "Submit" button
        submitButton.click();*/
		
		
	}

}
